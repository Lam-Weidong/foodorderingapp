# foodorderingapp
Comp3122 project


# How to test
cd orderapi
#
docker-compose up
# new terminal
cd tests
# install pytest
pip install pytest 
# install flask
pip install flask

# test
pytest -v unit.py